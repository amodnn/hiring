import os
import json
import pdfplumber
import tempfile
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
from supabase import create_client
from groq import Groq

load_dotenv()

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_methods=["*"],
    allow_headers=["*"],
)

supabase = create_client(
    os.getenv("SUPABASE_URL"),
    os.getenv("SUPABASE_KEY")
)

groq_client = Groq(api_key=os.getenv("GROQ_API_KEY"))


def build_scoring_prompt(resume_text: str, profile: dict, criteria: list, questions: list) -> str:
    criteria_block = "\n".join([
        f"- {c['name']} (weight: {c['weight']}%): {c['description']}"
        for c in criteria
    ])

    questions_block = "\n".join([
        f"Q: {q['question']}\n  Strong answer: {q['strong_answer_guide']}\n  Red flags: {q['red_flags']}"
        for q in questions
    ])

    level_guidance = {
        'associate': 'Entry level, 1-3 years experience. Evaluate on basic knowledge, learning agility, and potential. Do not expect deep expertise.',
        'fullstack': 'Mid level, 3-6 years experience. Evaluate on E2E ownership, code quality, and independent delivery. Not expected to lead.',
        'senior': 'Senior level, 7+ years experience. Evaluate on technical leadership, team management, mentoring, and deployment ownership. Must show leadership evidence.',
    }.get(profile['seniority'], '')

    return f"""
You are an expert technical hiring evaluator for the Customer Experience Desktop (CED) project.

ROLE: {profile['title']}
TECHNOLOGY: {profile['tech_stack']}
SENIORITY: {profile['seniority'].upper()}
LEVEL GUIDANCE: {level_guidance}

IMPORTANT RULES:
- Evaluate ONLY against the criteria and seniority level defined above.
- Do NOT penalise for skills outside the {profile['tech_stack']} stack.
- An overqualified candidate should score lower on level-fit criteria.
- An underqualified candidate should also score lower where evidence is missing.
- Base all scores strictly on evidence found in the resume. Do not assume.

EVALUATION CRITERIA (score each from 0 to 100):
{criteria_block}

INTERVIEW RUBRIC (use these to identify red flags from resume evidence):
{questions_block}

CANDIDATE RESUME:
{resume_text}

YOUR TASK:
1. Score the candidate on each criterion from 0-100 based on resume evidence only.
2. Compute the weighted composite score using the weights above.
3. List any red flags from the rubric that are evident in the resume.
4. Write a 2-3 sentence executive summary for the hiring lead.

RESPOND ONLY WITH THIS EXACT JSON — no preamble, no explanation, no markdown:
{{
  "criteria_scores": {{
    {', '.join([f'"{c["name"]}": <score_0_to_100>' for c in criteria])}
  }},
  "composite_score": <weighted_average_integer>,
  "ai_analysis": "<2-3 sentence executive summary for hiring lead>",
  "red_flags": "<comma separated red flags from resume evidence, or empty string if none>"
}}
"""


@app.get("/")
def root():
    return {"status": "CED hiring backend running"}


@app.post("/parse-resume")
async def parse_resume(
    file: UploadFile = File(...),
    role_profile_id: str = Form(...),
    candidate_name: str = Form(...),
    candidate_email: str = Form(...)
):
    # Save uploaded file to temp
    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
        contents = await file.read()
        tmp.write(contents)
        tmp_path = tmp.name

    # Extract text using pdfplumber
    resume_text = ""
    with pdfplumber.open(tmp_path) as pdf:
        for page in pdf.pages:
            text = page.extract_text()
            if text:
                resume_text += text + "\n"

    os.unlink(tmp_path)

    if not resume_text.strip():
        return {"error": "Could not extract text from PDF. Make sure it is not a scanned image."}

    # Save candidate to Supabase
    result = supabase.table("candidates").insert({
        "role_profile_id": role_profile_id,
        "name": candidate_name,
        "email": candidate_email,
        "resume_text": resume_text
    }).execute()

    candidate_id = result.data[0]["id"]

    # Fetch role profile, criteria, questions
    profile = supabase.table("role_profiles").select("*").eq("id", role_profile_id).single().execute().data
    criteria = supabase.table("criteria").select("*").eq("role_profile_id", role_profile_id).execute().data
    questions = supabase.table("questions").select("*").eq("role_profile_id", role_profile_id).execute().data

    # Build prompt and call Groq
    prompt = build_scoring_prompt(resume_text, profile, criteria, questions)

    chat = groq_client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2
    )

    raw = chat.choices[0].message.content.strip()

    # Parse JSON response
    try:
        scores = json.loads(raw)
    except json.JSONDecodeError:
        return {"error": "AI returned malformed JSON", "raw": raw}

    # Save scores to Supabase
    supabase.table("scores").insert({
        "candidate_id": candidate_id,
        "composite_score": scores.get("composite_score"),
        "ai_analysis": scores.get("ai_analysis"),
        "red_flags": scores.get("red_flags"),
        "criteria_scores": scores.get("criteria_scores")
    }).execute()

    return {
        "status": "scored",
        "candidate_id": candidate_id,
        "composite_score": scores.get("composite_score"),
        "ai_analysis": scores.get("ai_analysis"),
        "red_flags": scores.get("red_flags"),
        "criteria_scores": scores.get("criteria_scores")
    }
