import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'CED AI Hiring Tool',
  description: 'Customer Experience Desktop — AI Powered Hiring POC',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
