'use client'

import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

const LEVELS = [
  { seniority: 'associate', label: 'Associate Developer', exp: '1–3 years' },
  { seniority: 'fullstack', label: 'Full Stack Developer', exp: '3–6 years' },
  { seniority: 'senior', label: 'Senior Developer', exp: '7+ years' },
]

const TECHS = ['Java', 'Salesforce']

export default function Home() {
  const [profiles, setProfiles] = useState<any[]>([])
  const [expanded, setExpanded] = useState<string | null>(null)
  const [criteria, setCriteria] = useState<Record<string, any[]>>({})
  const [questions, setQuestions] = useState<Record<string, any[]>>({})
  const [loading, setLoading] = useState(true)

  useEffect(() => { fetchProfiles() }, [])

  async function fetchProfiles() {
    const { data } = await supabase.from('role_profiles').select('*')
    setProfiles(data || [])
    setLoading(false)
  }

  async function toggleExpand(profile: any) {
    const key = profile.id
    if (expanded === key) { setExpanded(null); return }
    setExpanded(key)
    if (!criteria[key]) {
      const { data: c } = await supabase.from('criteria').select('*').eq('role_profile_id', key)
      const { data: q } = await supabase.from('questions').select('*').eq('role_profile_id', key)
      setCriteria(prev => ({ ...prev, [key]: c || [] }))
      setQuestions(prev => ({ ...prev, [key]: q || [] }))
    }
  }

  function getProfile(tech: string, seniority: string) {
    return profiles.find(p => p.tech_stack === tech && p.seniority === seniority)
  }

  if (loading) return <p style={s.loading}>Loading CED roles...</p>

  return (
    <main style={s.main}>
      <div style={s.header}>
        <div style={s.projectBadge}>Project — CED</div>
        <h1 style={s.title}>Customer Experience Desktop</h1>
        <p style={s.sub}>Click any role block to view evaluation criteria and interview rubric</p>
        <div style={s.navRow}>
          <a href="/upload" style={s.navBtn('#378ADD', 'white')}>+ Upload candidate</a>
          <a href="/pipeline" style={s.navBtn('#f3f4f6', '#333')}>View pipeline →</a>
        </div>
      </div>

      <div style={s.gridHeader}>
        <div />
        {TECHS.map(tech => (
          <div key={tech} style={{ textAlign: 'center' as const }}>
            <span style={s.techBadge(tech)}>{tech}</span>
          </div>
        ))}
      </div>

      {LEVELS.map(level => (
        <div key={level.seniority}>
          <div style={s.gridRow}>
            <div style={s.rowLabel}>
              <div style={s.rowTitle}>{level.label}</div>
              <div style={s.rowExp}>{level.exp}</div>
            </div>
            {TECHS.map(tech => {
              const profile = getProfile(tech, level.seniority)
              if (!profile) return <div key={tech} style={s.cell} />
              const isOpen = expanded === profile.id
              return (
                <div key={tech} style={s.clickableCell(isOpen, tech)} onClick={() => toggleExpand(profile)}>
                  <div style={s.cellTop}>
                    <span style={s.techBadge(tech)}>{tech}</span>
                    <span style={s.caret}>{isOpen ? '▲' : '▼'}</span>
                  </div>
                  <div style={s.cellTitle}>{level.label}</div>
                  <div style={s.cellExp}>{level.exp}</div>
                </div>
              )
            })}
          </div>

          {TECHS.map(tech => {
            const profile = getProfile(tech, level.seniority)
            if (!profile || expanded !== profile.id) return null
            const c = criteria[profile.id] || []
            const q = questions[profile.id] || []
            return (
              <div key={tech} style={s.expandedPanel}>
                <div style={s.expandedHeader}>
                  <div>
                    <span style={s.techBadge(tech)}>{tech}</span>
                    <span style={s.expandedTitle}> — {level.label}</span>
                  </div>
                  <span style={s.expBadge}>{level.exp}</span>
                </div>
                <p style={s.profileDesc}>{profile.description}</p>
                <div style={s.twoCol}>
                  <div>
                    <div style={s.sectionTitle}>Evaluation criteria</div>
                    {c.map(cr => (
                      <div key={cr.id} style={s.criteriaRow}>
                        <div>
                          <div style={s.criteriaName}>{cr.name}</div>
                          <div style={s.criteriaDesc}>{cr.description}</div>
                        </div>
                        <div style={s.weightBadge}>{cr.weight}%</div>
                      </div>
                    ))}
                    <div style={s.totalRow}>Total: <strong>{c.reduce((a, cr) => a + cr.weight, 0)}%</strong></div>
                  </div>
                  <div>
                    <div style={s.sectionTitle}>Interview rubric</div>
                    {q.map((qu, i) => (
                      <div key={qu.id} style={s.questionCard}>
                        <div style={s.qNum}>Q{i + 1}</div>
                        <div>
                          <div style={s.qText}>{qu.question}</div>
                          <div style={s.qGuide}>✅ {qu.strong_answer_guide}</div>
                          <div style={s.qFlag}>🚩 {qu.red_flags}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <div style={s.ctaRow}>
                  <a href={`/upload?profileId=${profile.id}`} style={s.navBtn('#378ADD', 'white')}>
                    Upload candidate for this role →
                  </a>
                </div>
              </div>
            )
          })}
        </div>
      ))}
    </main>
  )
}

const s: any = {
  main: { maxWidth: 860, margin: '0 auto', padding: '2rem 1.5rem', fontFamily: 'system-ui, sans-serif' },
  loading: { padding: '2rem', color: '#888' },
  header: { marginBottom: '1.5rem' },
  projectBadge: { display: 'inline-block', fontSize: 11, fontWeight: 600, background: '#E6F1FB', color: '#185FA5', padding: '2px 10px', borderRadius: 20, marginBottom: 8 },
  title: { fontSize: 22, fontWeight: 700, color: '#111', margin: '0 0 4px' },
  sub: { fontSize: 13, color: '#888', marginBottom: 12 },
  navRow: { display: 'flex', gap: 10 },
  navBtn: (bg: string, color: string) => ({ fontSize: 13, padding: '7px 14px', background: bg, color, borderRadius: 8, textDecoration: 'none', fontWeight: 500 }),
  techBadge: (t: string) => ({ display: 'inline-block', fontSize: 11, fontWeight: 600, padding: '2px 10px', borderRadius: 20, background: t === 'Java' ? '#FAEEDA' : '#E6F1FB', color: t === 'Java' ? '#854F0B' : '#185FA5' }),
  gridHeader: { display: 'grid', gridTemplateColumns: '180px 1fr 1fr', gap: 8, marginBottom: 8, padding: '0 0 4px' },
  gridRow: { display: 'grid', gridTemplateColumns: '180px 1fr 1fr', gap: 8, marginBottom: 8 },
  rowLabel: { display: 'flex', flexDirection: 'column' as const, justifyContent: 'center', padding: '0 8px' },
  rowTitle: { fontSize: 13, fontWeight: 600, color: '#111' },
  rowExp: { fontSize: 12, color: '#888', marginTop: 2 },
  cell: { border: '1px solid #e5e7eb', borderRadius: 10, padding: '12px 14px', background: 'white', minHeight: 80 },
  clickableCell: (open: boolean, tech: string) => ({
    border: `${open ? 2 : 1}px solid ${open ? (tech === 'Java' ? '#EF9F27' : '#378ADD') : '#e5e7eb'}`,
    borderRadius: 10, padding: '12px 14px', cursor: 'pointer',
    background: open ? (tech === 'Java' ? '#FAEEDA' : '#E6F1FB') : 'white',
    transition: 'all 0.15s',
  }),
  cellTop: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  cellTitle: { fontSize: 13, fontWeight: 600, color: '#111', marginBottom: 3 },
  cellExp: { fontSize: 12, color: '#888' },
  caret: { fontSize: 10, color: '#aaa' },
  expandedPanel: { marginBottom: 10, border: '1px solid #e5e7eb', borderRadius: 12, overflow: 'hidden' },
  expandedHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '1rem 1.5rem 0.5rem', background: '#fafafa' },
  expandedTitle: { fontSize: 15, fontWeight: 600, color: '#111' },
  expBadge: { fontSize: 12, color: '#888', background: '#f0f0f0', padding: '3px 10px', borderRadius: 20 },
  profileDesc: { fontSize: 13, color: '#666', lineHeight: 1.6, padding: '0 1.5rem 1rem', background: '#fafafa' },
  twoCol: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem', padding: '1rem 1.5rem', background: '#fafafa' },
  sectionTitle: { fontSize: 11, fontWeight: 600, color: '#999', textTransform: 'uppercase' as const, letterSpacing: '0.07em', marginBottom: 10 },
  criteriaRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'start', padding: '8px 0', borderBottom: '1px solid #f0f0f0' },
  criteriaName: { fontSize: 13, fontWeight: 500, color: '#111' },
  criteriaDesc: { fontSize: 12, color: '#888', marginTop: 2 },
  weightBadge: { fontSize: 13, fontWeight: 600, color: '#185FA5', minWidth: 36, textAlign: 'right' as const },
  totalRow: { fontSize: 12, color: '#888', textAlign: 'right' as const, marginTop: 8 },
  questionCard: { display: 'flex', gap: 10, padding: '8px 0', borderBottom: '1px solid #f0f0f0' },
  qNum: { fontSize: 12, fontWeight: 600, color: '#185FA5', minWidth: 22, paddingTop: 2 },
  qText: { fontSize: 13, fontWeight: 500, color: '#111', marginBottom: 5, lineHeight: 1.5 },
  qGuide: { fontSize: 12, color: '#3B6D11', marginBottom: 4, lineHeight: 1.5 },
  qFlag: { fontSize: 12, color: '#A32D2D', lineHeight: 1.5 },
  ctaRow: { padding: '1rem 1.5rem', background: '#fafafa', borderTop: '1px solid #e5e7eb' },
}
