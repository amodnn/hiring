'use client'

import { useEffect, useState, Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import { supabase } from '../../lib/supabase'

const TECHS = ['Java', 'Salesforce']
const LEVELS = [
  { seniority: 'associate', label: 'Associate' },
  { seniority: 'fullstack', label: 'Full Stack' },
  { seniority: 'senior', label: 'Senior' },
]

function AreasToProbe({ scores, profileId }: { scores: any, profileId: string }) {
  const [questions, setQuestions] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    supabase.from('questions').select('*').eq('role_profile_id', profileId)
      .then(({ data }) => { setQuestions(data || []); setLoading(false) })
  }, [profileId])

  if (loading) return <div style={{ fontSize: 12, color: '#aaa' }}>Loading...</div>

  const weakAreas = scores?.criteria_scores
    ? Object.entries(scores.criteria_scores).filter(([, v]: any) => v < 75).map(([k]: any) => k)
    : []

  return (
    <div>
      <div style={{ marginBottom: 12 }}>
        <div style={p.probeLabel('#185FA5')}>Technical questions</div>
        {questions.map((q, i) => (
          <div key={q.id} style={p.probeCard('#f3f4f6')}>
            <div style={p.probeQ}>Q{i + 1}. {q.question}</div>
            <div style={p.probeGuide}>✅ {q.strong_answer_guide}</div>
            <div style={p.probeFlag}>🚩 {q.red_flags}</div>
          </div>
        ))}
      </div>
      {weakAreas.length > 0 && (
        <div style={{ marginBottom: 12 }}>
          <div style={p.probeLabel('#854F0B')}>Probe deeper — scored below 75</div>
          {weakAreas.map(area => (
            <div key={area} style={p.probeCard('#FAEEDA')}>
              <div style={{ fontSize: 12, color: '#854F0B' }}>⚠ Ask more about: <strong>{area}</strong></div>
            </div>
          ))}
        </div>
      )}
      <div>
        <div style={p.probeLabel('#444')}>Behavioral questions</div>
        {[
          'Tell me about a time you disagreed with a technical decision. What did you do?',
          'Describe a situation where you had to learn something new under a tight deadline.',
          'Give an example of when you proactively identified and fixed a problem before it escalated.',
        ].map((q, i) => (
          <div key={i} style={p.probeCard('#f3f4f6')}>
            <div style={p.probeQ}>B{i + 1}. {q}</div>
          </div>
        ))}
      </div>
    </div>
  )
}

function PipelineInner() {
  const searchParams = useSearchParams()
  const [profiles, setProfiles] = useState<any[]>([])
  const [selectedTech, setSelectedTech] = useState('Java')
  const [selectedLevel, setSelectedLevel] = useState('associate')
  const [selectedProfile, setSelectedProfile] = useState<any>(null)
  const [allCandidates, setAllCandidates] = useState<any[]>([])
  const [selectedCandidate, setSelectedCandidate] = useState<any>(null)
  const [scores, setScores] = useState<any>(null)
  const [decision, setDecision] = useState('')
  const [note, setNote] = useState('')
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<'score' | 'probe'>('score')

  useEffect(() => { fetchEverything() }, [])

  async function fetchEverything() {
    const { data: profileData } = await supabase.from('role_profiles').select('*')
    const profileList = profileData || []
    setProfiles(profileList)

    const { data: candData } = await supabase.from('candidates').select('*').order('created_at', { ascending: false })
    const { data: decisionData } = await supabase.from('decisions').select('candidate_id, decision')

    const latestDecision: Record<string, string> = {}
    ;(decisionData || []).forEach((d: any) => { latestDecision[d.candidate_id] = d.decision })

    const enriched = (candData || []).map((c: any) => ({
      ...c,
      decisionStatus: latestDecision[c.id] || null,
      profile: profileList.find((pr: any) => pr.id === c.role_profile_id),
    }))

    const sorted = [
      ...enriched.filter(c => !c.decisionStatus),
      ...enriched.filter(c => c.decisionStatus === 'hold'),
      ...enriched.filter(c => c.decisionStatus === 'approve' || c.decisionStatus === 'reject'),
    ]

    setAllCandidates(sorted)
    setLoading(false)

    const candidateId = searchParams.get('candidateId')
    const profileId = searchParams.get('profileId')

    if (candidateId) {
      const match = sorted.find((c: any) => c.id === candidateId)
      if (match) await openCandidate(match)
    }
    if (profileId && !candidateId) {
      const profile = profileList.find((pr: any) => pr.id === profileId)
      if (profile) { setSelectedProfile(profile); setSelectedTech(profile.tech_stack); setSelectedLevel(profile.seniority) }
    }
  }

  async function openCandidate(candidate: any) {
    setSelectedCandidate(candidate)
    setSaved(false)
    setActiveTab('score')
    if (candidate.profile) { setSelectedProfile(candidate.profile); setSelectedTech(candidate.profile.tech_stack); setSelectedLevel(candidate.profile.seniority) }

    const { data: scoreData } = await supabase.from('scores').select('*').eq('candidate_id', candidate.id).single()
    setScores(scoreData || null)

    const { data: decisionData } = await supabase.from('decisions').select('*').eq('candidate_id', candidate.id).order('decided_at', { ascending: false }).limit(1).single()
    if (decisionData) { setDecision(decisionData.decision || ''); setNote(decisionData.note || '') }
    else { setDecision(''); setNote('') }
  }

  async function saveDecision(d: string) {
    if (!selectedCandidate) return
    setSaving(true); setSaved(false); setDecision(d)
    await supabase.from('decisions').insert({ candidate_id: selectedCandidate.id, decision: d, note, decided_at: new Date().toISOString() })
    setSaving(false); setSaved(true)
    await fetchEverything()
  }

  async function saveNote() {
    if (!selectedCandidate || !decision) return
    setSaving(true)
    await supabase.from('decisions').insert({ candidate_id: selectedCandidate.id, decision, note, decided_at: new Date().toISOString() })
    setSaving(false); setSaved(true)
  }

  function statusBadge(status: string | null) {
    if (!status) return <span style={s.badge('#FFF3CD', '#854F0B')}>Pending</span>
    if (status === 'approve') return <span style={s.badge('#EAF3DE', '#3B6D11')}>Selected</span>
    if (status === 'hold') return <span style={s.badge('#FAEEDA', '#854F0B')}>Hold</span>
    if (status === 'reject') return <span style={s.badge('#FCEBEB', '#A32D2D')}>Rejected</span>
    return null
  }

  if (loading) return <p style={s.loading}>Loading pipeline...</p>

  const pendingCount = allCandidates.filter(c => !c.decisionStatus).length

  return (
    <div style={s.layout}>
      <div style={s.sidebar}>
        <div style={s.sidebarHeader}>
          <div>
            <div style={s.sidebarTitle}>CED Pipeline</div>
            <div style={s.sidebarSub}>All roles · {allCandidates.length} candidates</div>
          </div>
          <a href="/upload" style={s.uploadLink}>+ Upload</a>
        </div>

        {pendingCount > 0 && (
          <div style={s.pendingBanner}>⏳ {pendingCount} candidate{pendingCount > 1 ? 's' : ''} awaiting decision</div>
        )}

        <div style={s.candList}>
          {allCandidates.length === 0 && (
            <p style={s.hint}>No candidates yet — <a href="/upload" style={{ color: '#378ADD' }}>upload one</a></p>
          )}

          {allCandidates.filter(c => !c.decisionStatus).length > 0 && <div style={s.listSection}>Pending decision</div>}
          {allCandidates.filter(c => !c.decisionStatus).map(c => (
            <div key={c.id} style={s.candCard(selectedCandidate?.id === c.id, null)} onClick={() => openCandidate(c)}>
              <div style={s.candTop}><div style={s.candName}>{c.name}</div>{statusBadge(null)}</div>
              <div style={s.candRole}>{c.profile?.tech_stack} · {c.profile?.title}</div>
              <div style={s.candDate}>{new Date(c.created_at).toLocaleDateString()}</div>
            </div>
          ))}

          {allCandidates.filter(c => c.decisionStatus === 'hold').length > 0 && <div style={s.listSection}>On hold</div>}
          {allCandidates.filter(c => c.decisionStatus === 'hold').map(c => (
            <div key={c.id} style={s.candCard(selectedCandidate?.id === c.id, 'hold')} onClick={() => openCandidate(c)}>
              <div style={s.candTop}><div style={s.candName}>{c.name}</div>{statusBadge('hold')}</div>
              <div style={s.candRole}>{c.profile?.tech_stack} · {c.profile?.title}</div>
              <div style={s.candDate}>{new Date(c.created_at).toLocaleDateString()}</div>
            </div>
          ))}

          {allCandidates.filter(c => c.decisionStatus === 'approve' || c.decisionStatus === 'reject').length > 0 && <div style={s.listSection}>Decided</div>}
          {allCandidates.filter(c => c.decisionStatus === 'approve' || c.decisionStatus === 'reject').map(c => (
            <div key={c.id} style={s.candCard(selectedCandidate?.id === c.id, c.decisionStatus)} onClick={() => openCandidate(c)}>
              <div style={s.candTop}><div style={s.candName}>{c.name}</div>{statusBadge(c.decisionStatus)}</div>
              <div style={s.candRole}>{c.profile?.tech_stack} · {c.profile?.title}</div>
              <div style={s.candDate}>{new Date(c.created_at).toLocaleDateString()}</div>
            </div>
          ))}
        </div>

        <div style={s.sidebarFooter}><a href="/" style={s.backLink}>← Back to roles</a></div>
      </div>

      <div style={s.detail}>
        {!selectedCandidate && (
          <div style={s.empty}>
            <div style={s.emptyTitle}>No candidate selected</div>
            <div style={s.emptySub}>{pendingCount > 0 ? `${pendingCount} candidate${pendingCount > 1 ? 's' : ''} awaiting your decision — select one from the left` : 'Select a candidate from the left'}</div>
          </div>
        )}

        {selectedCandidate && (
          <>
            <div style={s.detailHeader}>
              <div>
                <div style={s.detailName}>{selectedCandidate.name}</div>
                <div style={s.detailMeta}>{selectedCandidate.profile?.tech_stack} — {selectedCandidate.profile?.title} · {selectedCandidate.email}</div>
              </div>
              {scores && (
                <div style={s.scoreBig(scores.composite_score)}>
                  {scores.composite_score}
                  <span style={{ fontSize: 13, fontWeight: 400, color: '#888' }}>/100</span>
                </div>
              )}
            </div>

            <div style={s.tabs}>
              <div style={s.tab(activeTab === 'score')} onClick={() => setActiveTab('score')}>AI Score & Analysis</div>
              <div style={s.tab(activeTab === 'probe')} onClick={() => setActiveTab('probe')}>Areas to Probe</div>
            </div>

            {activeTab === 'score' && (
              <div style={s.tabContent}>
                {scores ? (
                  <>
                    <div style={s.section}>
                      <div style={s.sectionTitle}>AI analysis</div>
                      <div style={s.aiBox}>{scores.ai_analysis}</div>
                    </div>
                    {scores.red_flags && (
                      <div style={s.section}>
                        <div style={s.sectionTitle}>Red flags</div>
                        <div style={s.flagBox}>{scores.red_flags}</div>
                      </div>
                    )}
                    <div style={s.section}>
                      <div style={s.sectionTitle}>Criteria breakdown</div>
                      {Object.entries(scores.criteria_scores || {}).map(([key, val]: any) => (
                        <div key={key} style={s.barRow}>
                          <div style={s.barLabel}>{key}</div>
                          <div style={s.barTrack}><div style={s.barFill(val)} /></div>
                          <div style={s.barVal}>{val}</div>
                        </div>
                      ))}
                    </div>
                  </>
                ) : (
                  <div style={s.noScore}>No AI score yet for this candidate</div>
                )}

                <div style={s.decisionSection}>
                  <div style={s.sectionTitle}>Post-interview decision</div>
                  <div style={s.btnGroup}>
                    {['approve', 'hold', 'reject'].map(d => (
                      <button key={d} style={s.decisionBtn(d, decision === d)} onClick={() => saveDecision(d)}>
                        {d === 'approve' ? '✓ Select' : d === 'hold' ? '⏸ Hold' : '✕ Reject'}
                      </button>
                    ))}
                  </div>
                  <textarea style={s.noteInput} placeholder="Add interview notes here..." value={note} rows={3} onChange={e => setNote(e.target.value)} />
                  <button style={{ ...s.saveNoteBtn, opacity: saving ? 0.7 : 1 }} onClick={saveNote} disabled={saving || !decision}>
                    {saving ? 'Saving...' : 'Save note'}
                  </button>
                  {saved && <div style={s.savedBadge}>✓ Decision saved</div>}
                </div>
              </div>
            )}

            {activeTab === 'probe' && (
              <div style={s.tabContent}>
                <AreasToProbe scores={scores} profileId={selectedCandidate.role_profile_id} />
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}

export default function Pipeline() {
  return (
    <Suspense fallback={<p style={{ padding: '2rem', color: '#888' }}>Loading...</p>}>
      <PipelineInner />
    </Suspense>
  )
}

const s: any = {
  layout: { display: 'flex', height: '100vh', fontFamily: 'system-ui, sans-serif', background: '#f9fafb' },
  loading: { padding: '2rem', color: '#888' },
  sidebar: { width: 260, minWidth: 260, background: 'white', borderRight: '1px solid #e5e7eb', display: 'flex', flexDirection: 'column' as const },
  sidebarHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'start', padding: '1rem', borderBottom: '1px solid #e5e7eb' },
  sidebarTitle: { fontSize: 14, fontWeight: 600, color: '#111' },
  sidebarSub: { fontSize: 11, color: '#aaa', marginTop: 2 },
  uploadLink: { fontSize: 12, color: '#378ADD', textDecoration: 'none', fontWeight: 500 },
  pendingBanner: { background: '#FFF3CD', color: '#854F0B', fontSize: 12, fontWeight: 500, padding: '8px 1rem', borderBottom: '1px solid #F0D070' },
  candList: { flex: 1, overflowY: 'auto' as const, padding: '0.5rem 0.75rem' },
  hint: { fontSize: 12, color: '#aaa', textAlign: 'center' as const, marginTop: '1.5rem', lineHeight: 1.6 },
  listSection: { fontSize: 10, fontWeight: 600, color: '#bbb', textTransform: 'uppercase' as const, letterSpacing: '0.08em', padding: '8px 4px 4px' },
  candCard: (active: boolean, status: string | null) => ({ border: `${active ? 2 : 1}px solid ${active ? '#378ADD' : '#e5e7eb'}`, borderRadius: 10, padding: '10px 12px', marginBottom: 6, cursor: 'pointer', background: active ? '#E6F1FB' : 'white', opacity: status === 'reject' ? 0.6 : 1 }),
  candTop: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 3 },
  candName: { fontSize: 13, fontWeight: 600, color: '#111' },
  badge: (bg: string, color: string) => ({ fontSize: 10, fontWeight: 600, padding: '2px 7px', borderRadius: 20, background: bg, color }),
  candRole: { fontSize: 11, color: '#888', marginBottom: 3 },
  candDate: { fontSize: 11, color: '#bbb' },
  sidebarFooter: { padding: '0.75rem 1rem', borderTop: '1px solid #e5e7eb' },
  backLink: { fontSize: 12, color: '#888', textDecoration: 'none' },
  detail: { flex: 1, overflowY: 'auto' as const, padding: '1.5rem' },
  empty: { display: 'flex', flexDirection: 'column' as const, alignItems: 'center', justifyContent: 'center', height: '100%', gap: 8 },
  emptyTitle: { fontSize: 15, fontWeight: 500, color: '#888' },
  emptySub: { fontSize: 13, color: '#aaa', textAlign: 'center' as const },
  detailHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem', paddingBottom: '1rem', borderBottom: '1px solid #e5e7eb' },
  detailName: { fontSize: 18, fontWeight: 600, color: '#111' },
  detailMeta: { fontSize: 12, color: '#888', marginTop: 3 },
  scoreBig: (v: number) => ({ fontSize: 38, fontWeight: 700, color: v >= 80 ? '#3B6D11' : v >= 65 ? '#185FA5' : '#A32D2D', display: 'flex', alignItems: 'baseline', gap: 4 }),
  tabs: { display: 'flex', marginBottom: '1.25rem', borderBottom: '1px solid #e5e7eb' },
  tab: (active: boolean) => ({ padding: '8px 16px', fontSize: 13, fontWeight: active ? 600 : 400, color: active ? '#111' : '#888', cursor: 'pointer', borderBottom: active ? '2px solid #111' : '2px solid transparent', marginBottom: '-1px' }),
  tabContent: { paddingTop: '0.25rem' },
  section: { marginBottom: '1.25rem' },
  sectionTitle: { fontSize: 11, fontWeight: 600, color: '#999', textTransform: 'uppercase' as const, letterSpacing: '0.07em', marginBottom: 8 },
  aiBox: { background: '#f3f4f6', borderRadius: 8, padding: '10px 12px', fontSize: 13, color: '#333', lineHeight: 1.6 },
  flagBox: { background: '#FCEBEB', borderRadius: 8, padding: '10px 12px', fontSize: 13, color: '#A32D2D', lineHeight: 1.6 },
  noScore: { background: '#f3f4f6', borderRadius: 8, padding: '1rem', fontSize: 13, color: '#888', textAlign: 'center' as const },
  barRow: { display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 },
  barLabel: { fontSize: 12, color: '#555', width: 180, flexShrink: 0 },
  barTrack: { flex: 1, height: 6, borderRadius: 3, background: '#e5e7eb', overflow: 'hidden' },
  barFill: (v: number) => ({ height: '100%', width: `${v}%`, borderRadius: 3, background: v >= 80 ? '#639922' : v >= 65 ? '#378ADD' : '#E24B4A', transition: 'width 0.4s' }),
  barVal: { fontSize: 12, fontWeight: 600, color: '#111', width: 28, textAlign: 'right' as const },
  decisionSection: { borderTop: '1px solid #e5e7eb', paddingTop: '1.25rem', marginTop: '0.5rem' },
  btnGroup: { display: 'flex', gap: 8, marginBottom: 12 },
  decisionBtn: (d: string, active: boolean) => ({ flex: 1, padding: '8px 0', borderRadius: 8, border: active ? '2px solid' : '1px solid #e5e7eb', fontSize: 13, fontWeight: 500, cursor: 'pointer', background: d === 'approve' ? '#EAF3DE' : d === 'hold' ? '#FAEEDA' : '#FCEBEB', color: d === 'approve' ? '#3B6D11' : d === 'hold' ? '#854F0B' : '#A32D2D', borderColor: active ? (d === 'approve' ? '#3B6D11' : d === 'hold' ? '#854F0B' : '#A32D2D') : '#e5e7eb', outline: 'none' }),
  noteInput: { width: '100%', padding: '8px 10px', borderRadius: 8, border: '1px solid #e5e7eb', fontSize: 13, color: '#111', fontFamily: 'system-ui, sans-serif', resize: 'vertical' as const, boxSizing: 'border-box' as const },
  saveNoteBtn: { marginTop: 8, padding: '7px 16px', borderRadius: 8, background: '#111', color: 'white', border: 'none', fontSize: 13, fontWeight: 500, cursor: 'pointer' },
  savedBadge: { marginTop: 10, fontSize: 12, color: '#3B6D11', background: '#EAF3DE', padding: '6px 12px', borderRadius: 8, display: 'inline-block' },
}

const p: any = {
  probeLabel: (color: string) => ({ fontSize: 11, fontWeight: 600, color, marginBottom: 6, textTransform: 'uppercase' as const, letterSpacing: '0.06em' }),
  probeCard: (bg: string) => ({ background: bg, borderRadius: 8, padding: '8px 10px', marginBottom: 6 }),
  probeQ: { fontSize: 12, fontWeight: 500, color: '#111', marginBottom: 4, lineHeight: 1.5 },
  probeGuide: { fontSize: 11, color: '#3B6D11', marginBottom: 3, lineHeight: 1.5 },
  probeFlag: { fontSize: 11, color: '#A32D2D', lineHeight: 1.5 },
}
