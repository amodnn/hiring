'use client'

import { useState, useEffect, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'

const PROFILES = [
  { id: 'a0000001-0000-0000-0000-000000000001', tech: 'Java', level: 'Associate Developer', exp: '1–3 yrs' },
  { id: 'a0000001-0000-0000-0000-000000000002', tech: 'Java', level: 'Full Stack Developer', exp: '3–6 yrs' },
  { id: 'a0000001-0000-0000-0000-000000000003', tech: 'Java', level: 'Senior Developer', exp: '7+ yrs' },
  { id: 'b0000002-0000-0000-0000-000000000001', tech: 'Salesforce', level: 'Associate Developer', exp: '1–3 yrs' },
  { id: 'b0000002-0000-0000-0000-000000000002', tech: 'Salesforce', level: 'Full Stack Developer', exp: '3–6 yrs' },
  { id: 'b0000002-0000-0000-0000-000000000003', tech: 'Salesforce', level: 'Senior Developer', exp: '7+ yrs' },
]

function UploadInner() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [selectedProfile, setSelectedProfile] = useState<any>(PROFILES[0])
  const [file, setFile] = useState<File | null>(null)
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState('')

  useEffect(() => {
    const profileId = searchParams.get('profileId')
    if (profileId) {
      const match = PROFILES.find(p => p.id === profileId)
      if (match) setSelectedProfile(match)
    }
  }, [searchParams])

  async function handleSubmit() {
    if (!name || !email || !file) {
      setError('Please fill in all fields and upload a PDF.')
      return
    }
    setLoading(true)
    setError('')
    setResult(null)

    const formData = new FormData()
    formData.append('file', file)
    formData.append('candidate_name', name)
    formData.append('candidate_email', email)
    formData.append('role_profile_id', selectedProfile.id)

    try {
      const res = await fetch('http://localhost:8000/parse-resume', {
        method: 'POST',
        body: formData,
      })
      const data = await res.json()
      if (data.error) setError(data.error)
      else setResult(data)
    } catch {
      setError('Could not reach the backend. Make sure FastAPI is running on port 8000.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <main style={s.main}>
      <div style={s.card}>
        <div style={s.header}>
          <a href="/" style={s.back}>← Back to roles</a>
          <h1 style={s.title}>Upload candidate resume</h1>
          <p style={s.sub}>Resume will be parsed and AI scored against the selected role</p>
        </div>

        <div style={s.form}>
          <div style={s.field}>
            <label style={s.label}>Candidate name</label>
            <input style={s.input} placeholder="e.g. Rahul Mehta" value={name} onChange={e => setName(e.target.value)} />
          </div>
          <div style={s.field}>
            <label style={s.label}>Candidate email</label>
            <input style={s.input} placeholder="e.g. rahul@example.com" value={email} onChange={e => setEmail(e.target.value)} />
          </div>
          <div style={s.field}>
            <label style={s.label}>Role</label>
            <div style={s.roleGrid}>
              {PROFILES.map(p => (
                <div key={p.id} style={s.roleOption(selectedProfile?.id === p.id, p.tech)} onClick={() => setSelectedProfile(p)}>
                  <div style={s.roleTech(p.tech)}>{p.tech}</div>
                  <div style={s.roleLevel}>{p.level}</div>
                  <div style={s.roleExp}>{p.exp}</div>
                </div>
              ))}
            </div>
          </div>
          <div style={s.field}>
            <label style={s.label}>Resume PDF</label>
            <input type="file" accept=".pdf" onChange={e => setFile(e.target.files?.[0] || null)} />
            {file && <div style={s.fileChip}>📄 {file.name}</div>}
          </div>
          {error && <div style={s.error}>{error}</div>}
          <button style={{ ...s.btn, opacity: loading ? 0.7 : 1 }} onClick={handleSubmit} disabled={loading}>
            {loading ? '⏳ Scoring with AI...' : '🚀 Upload & score'}
          </button>
        </div>

        {result && (
          <div style={s.result}>
            <div style={s.resultHeader}>
              <div>
                <div style={s.resultName}>{name}</div>
                <div style={s.resultRole}>{selectedProfile.tech} — {selectedProfile.level} · {selectedProfile.exp}</div>
              </div>
              <div style={s.scoreBig(result.composite_score)}>
                {result.composite_score}
                <span style={{ fontSize: 14, fontWeight: 400, color: '#888' }}>/100</span>
              </div>
            </div>
            <div style={s.section}>
              <div style={s.sectionTitle}>AI analysis</div>
              <div style={s.aiBox}>{result.ai_analysis}</div>
            </div>
            {result.red_flags && (
              <div style={s.section}>
                <div style={s.sectionTitle}>Red flags</div>
                <div style={s.flagBox}>{result.red_flags}</div>
              </div>
            )}
            <div style={s.section}>
              <div style={s.sectionTitle}>Criteria breakdown</div>
              {Object.entries(result.criteria_scores || {}).map(([key, val]: any) => (
                <div key={key} style={s.barRow}>
                  <div style={s.barLabel}>{key}</div>
                  <div style={s.barTrack}><div style={s.barFill(val)} /></div>
                  <div style={s.barVal}>{val}</div>
                </div>
              ))}
            </div>
            <button style={s.pipelineBtn} onClick={() => router.push(`/pipeline?candidateId=${result.candidate_id}&profileId=${selectedProfile.id}`)}>
              View in pipeline →
            </button>
          </div>
        )}
      </div>
    </main>
  )
}

export default function Upload() {
  return (
    <Suspense fallback={<p style={{ padding: '2rem', color: '#888' }}>Loading...</p>}>
      <UploadInner />
    </Suspense>
  )
}

const s: any = {
  main: { minHeight: '100vh', background: '#f9fafb', display: 'flex', alignItems: 'start', justifyContent: 'center', padding: '2rem 1rem', fontFamily: 'system-ui, sans-serif' },
  card: { background: 'white', border: '1px solid #e5e7eb', borderRadius: 16, padding: '1.5rem 2rem', width: '100%', maxWidth: 600 },
  header: { marginBottom: '1.5rem', paddingBottom: '1rem', borderBottom: '1px solid #f0f0f0' },
  back: { fontSize: 12, color: '#888', textDecoration: 'none', display: 'block', marginBottom: 8 },
  title: { fontSize: 20, fontWeight: 600, color: '#111', margin: '0 0 4px' },
  sub: { fontSize: 13, color: '#888' },
  form: { display: 'flex', flexDirection: 'column' as const, gap: 16 },
  field: { display: 'flex', flexDirection: 'column' as const, gap: 6 },
  label: { fontSize: 12, fontWeight: 500, color: '#555' },
  input: { padding: '9px 12px', borderRadius: 8, border: '1px solid #e5e7eb', fontSize: 14, color: '#111', outline: 'none' },
  roleGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 },
  roleOption: (selected: boolean, tech: string) => ({
    padding: '10px 12px', borderRadius: 8, cursor: 'pointer',
    border: selected ? `2px solid ${tech === 'Java' ? '#EF9F27' : '#378ADD'}` : '1px solid #e5e7eb',
    background: selected ? (tech === 'Java' ? '#FAEEDA' : '#E6F1FB') : 'white',
    transition: 'all 0.15s',
  }),
  roleTech: (t: string) => ({ fontSize: 11, fontWeight: 600, color: t === 'Java' ? '#854F0B' : '#185FA5', marginBottom: 3 }),
  roleLevel: { fontSize: 13, fontWeight: 500, color: '#111', marginBottom: 2 },
  roleExp: { fontSize: 11, color: '#888' },
  fileChip: { fontSize: 12, color: '#185FA5', marginTop: 4 },
  error: { fontSize: 13, color: '#A32D2D', background: '#FCEBEB', padding: '8px 12px', borderRadius: 8 },
  btn: { padding: '10px 0', borderRadius: 8, background: '#378ADD', color: 'white', border: 'none', fontSize: 14, fontWeight: 500, cursor: 'pointer', marginTop: 4 },
  result: { marginTop: '1.5rem', paddingTop: '1.5rem', borderTop: '1px solid #e5e7eb' },
  resultHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' },
  resultName: { fontSize: 16, fontWeight: 600, color: '#111' },
  resultRole: { fontSize: 12, color: '#888', marginTop: 3 },
  scoreBig: (v: number) => ({ fontSize: 38, fontWeight: 700, color: v >= 80 ? '#3B6D11' : v >= 65 ? '#185FA5' : '#A32D2D', display: 'flex', alignItems: 'baseline', gap: 4 }),
  section: { marginBottom: '1.25rem' },
  sectionTitle: { fontSize: 11, fontWeight: 600, color: '#999', textTransform: 'uppercase' as const, letterSpacing: '0.07em', marginBottom: 8 },
  aiBox: { background: '#f3f4f6', borderRadius: 8, padding: '10px 12px', fontSize: 13, color: '#333', lineHeight: 1.6 },
  flagBox: { background: '#FCEBEB', borderRadius: 8, padding: '10px 12px', fontSize: 13, color: '#A32D2D', lineHeight: 1.6 },
  barRow: { display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 },
  barLabel: { fontSize: 12, color: '#555', width: 180, flexShrink: 0 },
  barTrack: { flex: 1, height: 6, borderRadius: 3, background: '#e5e7eb', overflow: 'hidden' },
  barFill: (v: number) => ({ height: '100%', width: `${v}%`, borderRadius: 3, background: v >= 80 ? '#639922' : v >= 65 ? '#378ADD' : '#E24B4A', transition: 'width 0.4s' }),
  barVal: { fontSize: 12, fontWeight: 600, color: '#111', width: 28, textAlign: 'right' as const },
  pipelineBtn: { width: '100%', padding: '9px 0', borderRadius: 8, background: '#111', color: 'white', border: 'none', fontSize: 13, fontWeight: 500, cursor: 'pointer', marginTop: 4 },
}
